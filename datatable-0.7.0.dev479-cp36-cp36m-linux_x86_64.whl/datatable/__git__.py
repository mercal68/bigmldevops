#!/usr/bin/env python3
# © H2O.ai 2018; -*- encoding: utf-8 -*-
#   This Source Code Form is subject to the terms of the
#   Mozilla Public License, v2.0. If a copy of the MPL was
#   not distributed with this file, You can obtain one at
#   http://mozilla.org/MPL/2.0/.
# ----------------------------------------------------------
# This file was auto-generated from ci/setup_utils.py

__git_revision__ = '157c6e90761f3e8345dacdade11e3462200a3740'
